/*
    **TCS230 library**
    this project was developed by:
    name: Kaique de Paula Siqueira
    user: ProgKai

    link to the github library:
    https://github.com/Kaiprograma/Mylibraries.git
*/

#ifndef TCS230_H
#define TCS230_H

#include <Arduino.h>

class TCS230
{
private:
    int _pinS0;
    int _pinS1;
    int _pinS2;
    int _pinS3;
    int _pinLED;
    int _pinOut;
public:
    TCS230(int pinS0, int pinS1, int pinS2, int pinS3, int pinOut, int pinLed);
    void TCS230_loop();

    int detectColor();

    float GetBlueValue();
    float GetGreenValue();
    float GetWhiteValue();
    float GetRedValue();
};

#endif