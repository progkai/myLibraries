/*
    **Ultrassonic library**
    this project was developed by:
    name: Kaique de Paula Siqueira
    user: ProgKai

    link to the github acount:
    https://github.com/Kaiprograma/Mylibraries.git
*/


#ifndef ULTRASSONIC_H
#define ULTRASSONIC_H

#include <Arduino.h>

class Ultrassonic
{
private:
    int _trigPin;
    int _echoPin;
    long time;
    int delayUltra = 200;
    long UltrassonicValue;
public:
    Ultrassonic(int trigPin, int echoPin);
    float UltrassonicRead();
};

#endif