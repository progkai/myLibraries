#include <Ultrassonic.h>
/*
    **Ultrassonic library**
    this project was developed by:
    name: Kaique de Paula Siqueira
    user: ProgKai

    link to the github acount:
    https://github.com/Kaiprograma/Mylibraries.git
*/

long ultrassonicValue;

Ultrassonic::Ultrassonic(int trigPin, int echoPin){
    pinMode(trigPin, OUTPUT);
    pinMode(echoPin, INPUT);
    _trigPin = trigPin;
    _echoPin = echoPin;
}
float Ultrassonic::UltrassonicRead()
    {
    if((millis() - delayUltra) > 200){
        digitalWrite(_trigPin, LOW);
        delayMicroseconds(2);
        digitalWrite(_trigPin, HIGH);
        delayMicroseconds(10);
        digitalWrite(_trigPin, LOW);
        time = pulseIn(_echoPin, HIGH);
        ultrassonicValue = time / 29 / 2 * 10;
    }
    if(millis() > 200){
        if (ultrassonicValue != 0){
            return ultrassonicValue;
        }
    }
}