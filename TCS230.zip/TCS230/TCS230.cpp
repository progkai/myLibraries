#include <TCS230.h>
/*
    **TCS230 library**
    this project was developed by:
    name: Kaique de Paula Siqueira
    user: ProgKai

    link to the github library:
    https://github.com/Kaiprograma/Mylibraries.git
*/

unsigned long valRed;
unsigned long valGreen;
unsigned long valBlue;
unsigned long valWhite;



TCS230::TCS230(int pinS0, int pinS1, int pinS2, int pinS3, int pinOut, int pinLed)
    {
    pinMode(pinS0, OUTPUT);
    pinMode(pinS1, OUTPUT);
    pinMode(pinS2, OUTPUT);
    pinMode(pinS3, OUTPUT);
    pinMode(pinLed, OUTPUT);
    pinMode(pinOut, INPUT);

    digitalWrite(pinS0, HIGH);
    digitalWrite(pinS1, LOW);

    digitalWrite(pinLed, HIGH);
}

void TCS230::TCS230_loop(){

    digitalWrite(_pinS2, LOW);
    digitalWrite(_pinS3, LOW);
    valRed = pulseIn(_pinOut, digitalRead(_pinOut) == HIGH ? LOW : HIGH);
  
    digitalWrite(_pinS2, HIGH);
    valWhite = pulseIn(_pinOut, digitalRead(_pinOut) == HIGH ? LOW : HIGH);

    digitalWrite(_pinS2, LOW);
    digitalWrite(_pinS3, HIGH);
    valBlue = pulseIn(_pinOut, digitalRead(_pinOut) == HIGH ? LOW : HIGH);

    digitalWrite(_pinS2, HIGH);
    valGreen = pulseIn(_pinOut, digitalRead(_pinOut) == HIGH ? LOW : HIGH);
}

float TCS230::GetBlueValue(){
    return valBlue;
}
float TCS230::GetGreenValue(){
    return valGreen;
}
float TCS230::GetWhiteValue(){
    return valWhite;
}
float TCS230::GetRedValue(){
    return valRed;
}

int TCS230::detectColor(){
    if ((valRed < valBlue) &&
      (valRed < valGreen) &&
      (valWhite < 100)) {
    return 0;
  } else if ((valBlue < valRed) &&  //Verifica se a cor azul foi detectada
             (valBlue < valGreen) &&
             (valWhite < 100)) {
    return 1;
  } else if ((valGreen < valRed) &&  //Verifica se a cor verde foi detectada
             (valGreen < valBlue) &&
             (valWhite < 100)) {
    return 2;
  }
}